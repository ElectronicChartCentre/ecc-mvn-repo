package com.bbn.openmap.util.http;

import java.io.IOException;

public class MockHttpResponse implements IHttpResponse{

    @Override
    public void writeHttpResponse(String contentType, String response) throws IOException {
    }

    @Override
    public void writeHttpResponse(String contentType, byte[] response) throws IOException {
    }

}
