package com.bbn.openmap.image.wms;

import java.awt.Paint;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import com.bbn.openmap.image.ImageFormatter;
import com.bbn.openmap.image.PNG8ImageFormatter;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.http.MockHttpResponse;

import junit.framework.TestCase;

public class WmsRequestHandlerTest extends TestCase {

    public void testEPSG4326CompleteWorld() throws Exception {
        Projection projC = createProjection("EPSG:4326", 256, 256,
                "-180,-85.051129502598,180,85.051129502598");
        assertEquals(5.122088E8, projC.getScale(), 1000);

        Projection projE1 = createProjection("EPSG:4326", 256, 256,
                "180,-85.051129502598,540,85.051129502598");
        assertEquals(5.122088E8, projE1.getScale(), 1000);

        Projection projW1 = createProjection("EPSG:4326", 256, 256,
                "-540,-85.051129502598,-180,85.051129502598");
        assertEquals(5.122088E8, projE1.getScale(), 1000);
    }

    private Projection createProjection(String crs, int width, int height, String bbox)
            throws Exception {

        PNG8ImageFormatter imageFormatter = new PNG8ImageFormatter();

        Properties rp = new Properties();
        rp.put("SRS", crs);
        rp.put("WIDTH", Integer.toString(width));
        rp.put("HEIGHT", Integer.toString(height));
        rp.put("BBOX", bbox);
        rp.put("FORMAT", imageFormatter.getContentType());
        rp.put("REQUEST", "GetMap");
        rp.put("VERSION", "1.1.1");
        rp.put("SERVICE", "WMS");
        rp.put("LAYERS", "dummy");

        List<Projection> resultingProjections = new ArrayList<>();

        WmsRequestHandler rh = new WmsRequestHandler("", "", 0, "", rp, Locale.US) {
            @Override
            public byte[] createImage(Projection proj, int scaledWidth, int scaledHeight,
                    List<String> showLayers, Paint background) {
                // not createing image, but pick up projection
                resultingProjections.add(proj);
                return null;
            }

            @Override
            public synchronized Map<String, ImageFormatter> getFormatters() {
                return Map.of(imageFormatter.getFormatName(), imageFormatter);
            }

            @Override
            void checkLayersAndStyles(Properties requestProperties,
                    GetMapRequestParameters parameters) throws WMSException {
                // skip to allow dummy layer
            }
        };
        rh.handleRequest(rp, new MockHttpResponse());

        assertEquals(1, resultingProjections.size());

        return resultingProjections.get(0);
    }

}
